export default interface ICustomer {
    id:number,
    firstName:string,
    lastName:string
}