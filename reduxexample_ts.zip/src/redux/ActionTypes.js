export const CREATE_NEW_CONTACT = "create_new_contact";
export const REMOVE_CONTACT = "remove_contact";

